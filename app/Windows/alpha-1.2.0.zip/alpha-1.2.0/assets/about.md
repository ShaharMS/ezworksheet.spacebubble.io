<align="center">
About Me
===
</align>

Hey there! My name is Shahar.
You might know me from my website, [spacebubble.io](https://spacebubble.io)

If you made it here, you probably also want to know what was behind creating this app. 
well, strap your seatbelts, ~~grab some popcorn~~ and lets go!


10 years ago, when i started school (damn im old), my "hatred" for worksheets begun. Thing is, it wasnt a "oh i don't wanna work" type of thing, i hated worksheets because they:

 - were super repetative
 - got lost easily
 - got heavy to carry after a while
 - were a hustle to manage without a proper ring binder

In colclusion, **W O R K S H E E T S   S U C K**.

Because of this, during my time in school i "sometimes" relied  on my classmates/friends to take pictures of those worksheets to help me. Those deserve a **MASSIVE** Thank-you, as they made the development of this program that much easier and more relaxing.

About a year ago, i started to learm programming. i started with a not-so-popular language that i found and really liked, [Haxe](https://haxe.org) I got to make a mobile game with it, which was boring, so i stopped making it. But - I liked the process. The next project i started was this one - I said to myself - If i already "know how to program" (I was trash when i started)why shouldnt i make a program that scans worksheets or something?

Now, That was a half-mistake, cause even tho my idea was pretty good and also pretty useful for school things, i sucked at programming, and creating a full on interpreter for the app just didnt really work out. i abandoned this project too, but only for a while.

In my time "away", I worked on some more cool things, such as a mobile game I'm planning to release soon, a code library to handle text inputs from right-to-left languages (hebrew, arabic...), a PDF to image convertor, and also learned many things relating to programming, but on that i won't alborate - it'll just be long and boring as hell.

when i did return to making this app i had a brilliant (im serious (well not really)) idea!

Why shouldnt I rewrite this app in a new programming framework? its more popular, has more support and overall more suited for this app!

The problem was - at that point, the application contained about 3000 lines of code, and about 1/5 of the program was already working. but I was determined, and it was a good idea indeed. I somehow made about a third of the app in **JUST THREE WEEKS** and it was still going great. I decided to continue using that programming framework.

And here you are, at least 4 months later, after this (kinda) long and hard journey, reading this.

## Thank you for installing my app and reading this far.


